package id.example.menuMakanan.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.List;

import id.example.menuMakanan.DetailActivity;
import id.example.menuMakanan.R;
import id.example.menuMakanan.model.Makanan;

public class AdapterMakanan extends RecyclerView.Adapter<AdapterMakanan.vieHolder> {
    List<Makanan> makananList;
    Context context;

    public AdapterMakanan(List<Makanan> makananList, Context context) {
        this.makananList = makananList;
        this.context = context;
    }

    @NonNull
    @Override
    public vieHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_makanan, parent, false);
        return new vieHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull vieHolder holder, int position) {

        holder.image.setImageResource(makananList.get(position).getDrawable());
        holder.nama.setText(makananList.get(position).getNama());
        holder.harga.setText(makananList.get(position).getHarga());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, DetailActivity.class);
                i.putExtra("makanan", (Serializable) makananList.get(position));
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return makananList.size();
    }

    public class vieHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView nama, harga;
        public vieHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.imageMakanan);
            nama = itemView.findViewById(R.id.namaMakanan);
            harga = itemView.findViewById(R.id.hargaMakanan);
        }
    }
}
