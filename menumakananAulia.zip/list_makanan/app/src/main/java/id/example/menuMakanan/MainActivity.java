package id.example.menuMakanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

import id.example.menuMakanan.adapter.AdapterMakanan;
import id.example.menuMakanan.model.Makanan;

public class MainActivity extends AppCompatActivity {
    RecyclerView rcMakanan;
    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
    AdapterMakanan adapterMakanan;
    List<Makanan> makananList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rcMakanan = findViewById(R.id.rcMakanan);
        rcMakanan.setHasFixedSize(true);
        rcMakanan.setLayoutManager(linearLayoutManager);

        setData();
    }

    private void setData(){
        Makanan makanan1 = new Makanan(
                "Kimchi",
                "30.000",
                "Salah satu makanan korea ini merupakan sayuran yang difermentasi dengan bumbu khas sehingga menghasilkan rasa yang pedas dan asam. Bagi masyarakat Korea, rasanya kurang sempurna jika saat makan tidak ada kimchi. Karena merupakan makanan yang difermentasikan, maka dari itu tentu makanan ini sangat tahan lama.",
                R.drawable.kimchi
        );
        Makanan makanan2 = new Makanan(
                "Sannakji",
                "70.000",
                "Untuk jenis makanan korea yang satu ini tidak semua orang sanggup memakannya. Bahkan ada beberapa orang Korea yang mengaku juga tidak bisa memakannya. Sannakji adalah makanan yang berasal dari gurita hidup yang dimakan dengan minyak atau biji wijen.",
                R.drawable.sannakji
        );
        Makanan makanan3 = new Makanan(
                "Jjajangmyeon",
                "25.000",
                "Makanan khas Korea yang satu ini juga pastinya sudah sering Anda lihat. Begitu populernya sehingga ada jjajangmyeon ini juga disajikan sebagai makanan instan. Hal yang paling khas dari makanan korea ini adalah saus kedelai hitam yang menjadikan mie yang satu ini menjadi berwarna hitam.",
                R.drawable.jjajangmyeon
        );
        Makanan makanan4 = new Makanan(
                "Kimbab",
                "15.000",
                "Nasi yang digulung dengan gim atau rumput laut kering yang di dalamnya berisi sayuran seperti wortel, bayam, timun, kemudian telur dan daging itu disebut dengan kimbab.",
                R.drawable.kimbab
        );
        Makanan makanan5 = new Makanan(
                "Bibimbap",
                "20.000",
                "Jika diartikan, maka bibimbap berarti nasi campur dan sesuai dengan namanya itu memang makanan korea ini merupakan nasi yang dicampur dan diaduk dengan berbagai macam lauk pauk yang ada di atasnya.",
                R.drawable.bibimbap
        );

        makananList.add(makanan1);
        makananList.add(makanan2);
        makananList.add(makanan3);
        makananList.add(makanan4);
        makananList.add(makanan5);

        adapterMakanan = new AdapterMakanan(makananList,MainActivity.this);
        rcMakanan.setAdapter(adapterMakanan);
    }
}