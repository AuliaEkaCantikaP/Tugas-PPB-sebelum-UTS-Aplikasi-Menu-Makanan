package id.example.menuMakanan.model;

import java.io.Serializable;

public class Makanan implements Serializable {
    String nama;
    String harga;
    String deskripsi;
    int drawable;

    public Makanan(String nama, String harga, String deskripsi, int drawable) {
        this.nama = nama;
        this.harga = harga;
        this.deskripsi = deskripsi;
        this.drawable = drawable;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public int getDrawable() {
        return drawable;
    }

    public void setDrawable(int drawable) {
        this.drawable = drawable;
    }
}
