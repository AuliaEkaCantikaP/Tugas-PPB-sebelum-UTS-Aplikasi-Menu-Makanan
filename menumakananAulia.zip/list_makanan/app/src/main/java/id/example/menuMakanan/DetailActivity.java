package id.example.menuMakanan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import id.example.menuMakanan.model.Makanan;

public class DetailActivity extends AppCompatActivity {
    ImageView image;
    TextView nama, harga, deskripsi;
    Makanan makanan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        image = findViewById(R.id.image);
        nama = findViewById(R.id.nama);
        harga = findViewById(R.id.harga);
        deskripsi = findViewById(R.id.deskripsi);

        makanan = (Makanan) getIntent().getSerializableExtra("makanan");

        image.setImageResource(makanan.getDrawable());
        nama.setText(makanan.getNama());
        harga.setText("Rp. "+makanan.getHarga());
        deskripsi.setText(makanan.getDeskripsi());
    }
}